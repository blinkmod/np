#!/usr/bin/env bash

. h-manifest.conf
# Export manifest-sourced names so the miner sees them as env vars.
# Sourced vars are shell-local by default; the miner needs them to
# detect HiveOS reliably and write /var/run/hive-miner-$MINER_NAME.stats.json.
export MINER_NAME CUSTOM_NAME CUSTOM_VERSION

# pgrep -x matches the exact process name, avoiding the regex-wildcard
# false positives the old `ps aux | grep "./nyxminer"` pattern hit
# (the `.` in that pattern matches any char, so any cmdline containing
# `X/nyxminer` for any X trips the check).
if pgrep -x lpminer > /dev/null 2>&1; then
  echo "lpminer miner is already running (pid $(pgrep -x lpminer))."
  exit 1
fi

conf=`cat $MINER_CONFIG_FILENAME`

echo $conf

if [[ $conf =~ ';' ]]; then
    conf=`echo $conf | tr -d '\'`
fi

echo "[DEBUG] WALLET: $CUSTOM_TEMPLATE"
echo "[DEBUG] WORKER: $WORKER_NAME"
echo "[DEBUG] CONFIG: $CUSTOM_USER_CONFIG"

eval "unbuffer ./lpminer ${conf//;/'\;'}"
