#!/usr/bin/env bash
# HiveOS sources this file inside /hive/bin/agent, not executes it — so we
# must set the two caller-scope variables `khs` (kH/s total) and `stats`
# (JSON the dashboard renders). nyxminer already emits the schema HiveOS
# expects ("hs"/"hs_units"/"ar"/"uptime"/"ver"/"algo"/...), so this is a
# pass-through. Keeps us aligned with the minershive/hiveos-linux custom
# miner README.

stats_raw=$(cat /var/run/hive-miner-lpminer.stats.json 2>/dev/null)

if [[ -n $stats_raw ]]; then
    khs=$(jq '[.hs[]] | add / 1000' <<< "$stats_raw" 2>/dev/null)
    stats=$(jq -c '.' <<< "$stats_raw" 2>/dev/null)
fi

[[ -z $khs ]] && khs=0
[[ -z $stats ]] && stats="null"
