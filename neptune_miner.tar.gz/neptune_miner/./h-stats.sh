#!/usr/bin/env bash

khs=0
stats=""

. /hive/miners/custom/neptune_miner/h-manifest.conf

stats_raw=`curl -s --connect-timeout 3 --max-time 5 http://127.0.0.1:${MINER_API_PORT}`

if [[ $? -ne 0 || -z $stats_raw ]]; then
  stats="null"
else
  gpu_stats=$(< $GPU_STATS_JSON)

  readarray -t gpu_stats < <( jq --slurp -r -c '.[] | .busids, .brand, .temp, .fan | join(" ")' $GPU_STATS_JSON 2>/dev/null)
  busids=(${gpu_stats[0]})
  brands=(${gpu_stats[1]})
  temps=(${gpu_stats[2]})
  fans=(${gpu_stats[3]})
  gpu_count=${#busids[@]}

  busid_arr=()
  fan_arr=()
  temp_arr=()
  lines=()
  hash_arr=()
  ttl_hr=0
  ac=0
  rj=0

  if [ $(gpu-detect NVIDIA) -gt 0 ]; then
    brand_gpu_count=$(gpu-detect NVIDIA)
    BRAND_MINER="nvidia"
  elif [ $(gpu-detect AMD) -gt 0 ]; then
    brand_gpu_count=$(gpu-detect AMD)
    BRAND_MINER="amd"
  fi

  for(( i=0; i < gpu_count; i++ )); do
    [[ "${brands[i]}" != $BRAND_MINER ]] && continue
    [[ "${busids[i]}" =~ ^([A-Fa-f0-9]+): ]]
    busid_arr+=($((16#${BASH_REMATCH[1]})))
    temp_arr+=(${temps[i]})
    fan_arr+=(${fans[i]})
    accepted=$(echo "$stats_raw" | jq -r ".gpus[\"$((i-1))\"].accepted")
    rejected=$(echo "$stats_raw" | jq -r ".gpus[\"$((i-1))\"].rejected")
    hashrate=$(echo "$stats_raw" | jq -r ".gpus[\"$((i-1))\"].hr")
    hash_arr+=($hashrate)
    ttl_hr=$(( ttl_hr + hashrate ))
    ac=$((ac + accepted))
    rj=$((rj + rejected))
  done

  hash_json=`printf '%s\n' "${hash_arr[@]}" | jq -cs '.'`
  bus_numbers=`printf '%s\n' "${busid_arr[@]}"  | jq -cs '.'`
  fan_json=`printf '%s\n' "${fan_arr[@]}"  | jq -cs '.'`
  temp_json=`printf '%s\n' "${temp_arr[@]}"  | jq -cs '.'`

  khs=$(( ttl_hr / 1000 ))
  version=$(echo "$stats_raw" | jq -cr ".version")
  uptime=$(echo "$stats_raw" | jq -r ".uptime_sec")

  stats=$(jq -nc \
    --argjson hs "$hash_json"\
    --arg ver "$version" \
    --arg ths "$ttl_hr" \
    --argjson ac "$ac" \
    --argjson rj "$rj" \
    --argjson bus_numbers "$bus_numbers" \
    --argjson fan "$fan_json" \
    --argjson temp "$temp_json" \
    --arg uptime "$uptime" \
    '{ hs: $hs, hs_units: "hs", "ths": $ths, algo : "neptune", ver:$ver, ar:[$ac,$rj], $uptime, $bus_numbers, $temp, $fan}')

fi

echo "$stats"

